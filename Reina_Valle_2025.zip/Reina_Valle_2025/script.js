const form = document.getElementById('votingForm');
const sheetURL = 'https://script.google.com/d/1Y3X-i5iYEnLNEz5hmEQUwEAGGls2xtpRPWAsVW5gbWTBmf8n19Us8qVV/edit?usp=sharing';

form.addEventListener('submit', (e) => {
  e.preventDefault();

  // Validar si ya votó
  if (document.cookie.includes('votado=true')) {
    alert("¡Ya has votado! Gracias por tu participación.");
    return;
  }

  const candidata = document.querySelector('input[name="candidata"]:checked');
  if (!candidata) {
    alert("Selecciona una candidata antes de votar.");
    return;
  }

  fetch(sheetURL, {
    method: 'POST',
    mode: 'no-cors',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `voto=${encodeURIComponent(candidata.value)}`
  });

  document.cookie = "votado=true; max-age=" + (60 * 60 * 24 * 30); // 30 días
  alert("¡Gracias por tu voto!");
  form.reset();
});
